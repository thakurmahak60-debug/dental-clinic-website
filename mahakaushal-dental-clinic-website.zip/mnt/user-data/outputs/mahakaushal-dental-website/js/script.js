// ==========================================================================
// Mahakaushal Dental Clinic — Site Script
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {

  /* ---------------- Loader ---------------- */
  const loader = document.getElementById('loader');
  window.addEventListener('load', () => {
    setTimeout(() => loader.classList.add('hide'), 400);
  });
  // Fallback in case 'load' already fired
  setTimeout(() => loader.classList.add('hide'), 2500);

  /* ---------------- Year ---------------- */
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------------- Icons library (inline SVG strings) ---------------- */
  const ICONS = {
    tooth: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3c-2.5 0-3.5 1.4-5 1.4C5.2 4.4 4 3.6 3 4c-1.5.6-1.7 3-1 5.5.6 2.2 1.6 3.8 2 6.5.3 2 .6 4.5 2 4.5 1.6 0 1.6-3.3 2.3-5.6.3-1 .8-1.6 1.7-1.6s1.4.6 1.7 1.6C12.4 17.2 12.4 20.5 14 20.5c1.4 0 1.7-2.5 2-4.5.4-2.7 1.4-4.3 2-6.5.7-2.5.5-4.9-1-5.5-1-.4-2.2.4-4 .4-1.5 0-2.5-1.4-5-1.4Z"/></svg>',
    drill: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2l6 6-9 9-6-1-1-6 9-9z"/><path d="M4 20l3-3"/></svg>',
    sparkle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2l1.6 4.8L18 8l-4.4 1.2L12 14l-1.6-4.8L6 8l4.4-1.2L12 2z"/></svg>',
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 22s8-4.5 8-11V5l-8-3-8 3v6c0 6.5 8 11 8 11z"/></svg>',
    braces: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 10h18M3 14h18"/><circle cx="6" cy="10" r="1.2" fill="currentColor"/><circle cx="12" cy="10" r="1.2" fill="currentColor"/><circle cx="18" cy="10" r="1.2" fill="currentColor"/><circle cx="6" cy="14" r="1.2" fill="currentColor"/><circle cx="12" cy="14" r="1.2" fill="currentColor"/><circle cx="18" cy="14" r="1.2" fill="currentColor"/></svg>',
    smile: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01"/></svg>',
    bridge: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 20V10a10 10 0 0 1 20 0v10"/><path d="M6 20v-6M12 20v-8M18 20v-6"/></svg>',
    denture: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 10c0-3 4-5 9-5s9 2 9 5-4 5-9 5-9-2-9-5z"/><path d="M4 14c1 3 4 5 8 5s7-2 8-5"/></svg>',
    child: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.5-7 8-7s8 3 8 7"/></svg>',
    extract: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2v14M6 8l6 6 6-6"/><path d="M6 20h12"/></svg>',
    scale: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v18M5 8l-3 6a3 3 0 0 0 6 0zM19 8l-3 6a3 3 0 0 0 6 0zM5 8h14"/></svg>'
  };

  /* ---------------- Services data ---------------- */
  const services = [
    { title: 'Root Canal Treatment', desc: 'Gentle, precise root canal therapy to save infected teeth and relieve pain.', icon: ICONS.tooth, img: 'images/treatment-room.jpg' },
    { title: 'Teeth Cleaning', desc: 'Professional cleaning to remove plaque, tartar and surface stains.', icon: ICONS.sparkle, img: 'images/doctor-treatment-room.jpg' },
    { title: 'Scaling', desc: 'Deep cleaning below the gumline to prevent gum disease.', icon: ICONS.scale, img: 'images/treatment-room.jpg' },
    { title: 'Dental Fillings', desc: 'Tooth-coloured fillings that restore strength and a natural look.', icon: ICONS.tooth, img: 'images/doctor-patient-checkup.jpg' },
    { title: 'Tooth Extraction', desc: 'Safe, comfortable removal of damaged or problematic teeth.', icon: ICONS.extract, img: 'images/treatment-room.jpg' },
    { title: 'Dental Implants', desc: 'Permanent, natural-feeling replacements for missing teeth.', icon: ICONS.bridge, img: 'images/doctor-treatment-room.jpg' },
    { title: 'Braces', desc: 'Modern orthodontic solutions to gradually straighten your smile.', icon: ICONS.braces, img: 'images/before-after-top.jpg' },
    { title: 'Smile Designing', desc: 'A customized plan to reshape and brighten your entire smile.', icon: ICONS.smile, img: 'images/before-after-bottom.jpg' },
    { title: 'Crowns & Bridges', desc: 'Durable restorations that repair or replace damaged teeth.', icon: ICONS.bridge, img: 'images/doctor-patient-checkup.jpg' },
    { title: 'Dentures', desc: 'Comfortable, natural-looking dentures for full or partial tooth loss.', icon: ICONS.denture, img: 'images/reception-desk.jpg' },
    { title: 'Pediatric Dentistry', desc: 'Gentle, friendly dental care designed specifically for children.', icon: ICONS.child, img: 'images/office-desk.jpg' },
    { title: 'Cosmetic Dentistry', desc: 'Whitening, veneers and shaping to help you love your smile.', icon: ICONS.sparkle, img: 'images/doctor-portrait.jpg' }
  ];

  const servicesGrid = document.getElementById('servicesGrid');
  if (servicesGrid) {
    servicesGrid.innerHTML = services.map(s => `
      <div class="service-card reveal">
        <div class="service-media">
          <img src="${s.img}" alt="${s.title} at Mahakaushal Dental Clinic" loading="lazy">
          <span class="overlay-icon">${s.icon}</span>
        </div>
        <div class="service-body">
          <h3>${s.title}</h3>
          <p>${s.desc}</p>
          <a href="#appointment" class="learn">Learn More <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
        </div>
      </div>
    `).join('');
  }

  /* ---------------- Gallery data ---------------- */
  const galleryItems = [
    { img: 'images/clinic-signboard.jpg', label: 'Clinic Signboard', cat: 'clinic' },
    { img: 'images/reception-desk.jpg', label: 'Reception & Consultation Desk', cat: 'clinic' },
    { img: 'images/treatment-room.jpg', label: 'Dental Treatment Room', cat: 'treatment' },
    { img: 'images/office-desk.jpg', label: 'Doctor\'s Office', cat: 'clinic' },
    { img: 'images/doctor-treatment-room.jpg', label: 'Dr. Sonali Agrawal at Work', cat: 'team' },
    { img: 'images/doctor-portrait.jpg', label: 'Dr. Sonali Agrawal', cat: 'team' },
    { img: 'images/doctor-patient-checkup.jpg', label: 'Patient Check-up', cat: 'treatment' }
  ];

  const masonryGrid = document.getElementById('masonryGrid');
  if (masonryGrid) {
    masonryGrid.innerHTML = galleryItems.map(g => `
      <div class="masonry-item reveal-scale" data-cat="${g.cat}">
        <img src="${g.img}" alt="${g.label} — Mahakaushal Dental Clinic" loading="lazy">
        <div class="m-overlay"><span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>${g.label}</span></div>
      </div>
    `).join('');

    // Lightbox
    const lightbox = document.getElementById('lightbox');
    const lbImg = document.getElementById('lbImg');
    masonryGrid.addEventListener('click', (e) => {
      const item = e.target.closest('.masonry-item');
      if (!item) return;
      const img = item.querySelector('img');
      lbImg.src = img.src;
      lbImg.alt = img.alt;
      lightbox.classList.add('open');
    });
    document.getElementById('lbClose').addEventListener('click', () => lightbox.classList.remove('open'));
    lightbox.addEventListener('click', (e) => { if (e.target === lightbox) lightbox.classList.remove('open'); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') lightbox.classList.remove('open'); });

    // Filters
    document.querySelectorAll('.gfilter').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.gfilter').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filter = btn.dataset.filter;
        document.querySelectorAll('.masonry-item').forEach(item => {
          const match = filter === 'all' || item.dataset.cat === filter;
          item.classList.toggle('hidden-item', !match);
        });
      });
    });
  }

  /* ---------------- FAQ data ---------------- */
  const faqs = [
    { q: 'Is root canal treatment painful?', a: 'Modern root canal treatment is performed under local anaesthesia, so the procedure itself is virtually painless. Mild sensitivity for a day or two afterward is normal and manageable with medication.' },
    { q: 'How long does dental treatment take?', a: 'It depends on the procedure — a cleaning may take around 30 minutes, while a root canal or implant can take one to a few sittings. We share a clear time estimate during your consultation.' },
    { q: 'Are appointments necessary?', a: 'We recommend booking ahead so we can give you unhurried attention, though we do our best to accommodate walk-ins and emergencies.' },
    { q: 'Do you treat children?', a: 'Yes — we provide gentle, child-friendly dental care including check-ups, cavity treatment and guidance on healthy oral habits for young patients.' },
    { q: 'What payment methods are accepted?', a: 'We accept cash, UPI and major cards. Please ask our front desk about current options.' },
    { q: 'Is emergency treatment available?', a: 'Yes — call or WhatsApp us directly for dental emergencies and we will guide you on the fastest way to be seen.' }
  ];

  const faqList = document.getElementById('faqList');
  if (faqList) {
    faqList.innerHTML = faqs.map((f, i) => `
      <div class="faq-item reveal" data-i="${i}">
        <button class="faq-q" aria-expanded="false">
          <span>${f.q}</span>
          <span class="plus"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg></span>
        </button>
        <div class="faq-a"><p>${f.a}</p></div>
      </div>
    `).join('');

    faqList.querySelectorAll('.faq-q').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = btn.closest('.faq-item');
        const answer = item.querySelector('.faq-a');
        const isOpen = item.classList.contains('open');
        // close all
        faqList.querySelectorAll('.faq-item').forEach(el => {
          el.classList.remove('open');
          el.querySelector('.faq-a').style.maxHeight = null;
          el.querySelector('.faq-q').setAttribute('aria-expanded', 'false');
        });
        if (!isOpen) {
          item.classList.add('open');
          answer.style.maxHeight = answer.scrollHeight + 'px';
          btn.setAttribute('aria-expanded', 'true');
        }
      });
    });
  }

  /* ---------------- Navbar scroll state ---------------- */
  const navbar = document.getElementById('navbar');
  const onScroll = () => {
    navbar.classList.toggle('scrolled', window.scrollY > 40);
    fabTop.classList.toggle('show', window.scrollY > 500);
    updateActiveNav();
    updateTimelineProgress();
  };
  window.addEventListener('scroll', onScroll, { passive: true });

  /* ---------------- Mobile menu ---------------- */
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    mobileMenu.classList.toggle('open');
    hamburger.setAttribute('aria-expanded', mobileMenu.classList.contains('open'));
  });
  mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    hamburger.classList.remove('active');
    mobileMenu.classList.remove('open');
  }));
  window.addEventListener('resize', () => {
    if (window.innerWidth > 940) {
      hamburger.classList.remove('active');
      mobileMenu.classList.remove('open');
    }
  });

  /* ---------------- Active nav link on scroll ---------------- */
  const sections = ['home','about','services','gallery','testimonials','faq','contact']
    .map(id => document.getElementById(id) || document.querySelector(`#${id}`))
    .filter(Boolean);
  const navAnchors = document.querySelectorAll('.nav-links a');
  function updateActiveNav() {
    let current = 'home';
    const scrollPos = window.scrollY + 140;
    document.querySelectorAll('main > section[id], #hero').forEach(sec => {
      if (sec.offsetTop <= scrollPos) current = sec.id;
    });
    navAnchors.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + current));
  }

  /* ---------------- Theme toggle ---------------- */
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = document.getElementById('themeIcon');
  const savedTheme = null; // no localStorage per artifact constraints; session-only in-memory
  let currentTheme = 'light';
  themeToggle.addEventListener('click', () => {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', currentTheme === 'dark' ? 'dark' : 'light');
    themeIcon.innerHTML = currentTheme === 'dark'
      ? '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>'
      : '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
  });

  /* ---------------- Scroll reveal (IntersectionObserver) ---------------- */
  const revealEls = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });
  revealEls.forEach(el => revealObserver.observe(el));
  // Re-observe dynamically injected elements
  setTimeout(() => {
    document.querySelectorAll('.reveal:not(.in), .reveal-left:not(.in), .reveal-right:not(.in), .reveal-scale:not(.in)')
      .forEach(el => revealObserver.observe(el));
  }, 50);

  /* ---------------- Timeline progress + step activation ---------------- */
  const timeline = document.getElementById('timeline');
  const tlSteps = document.querySelectorAll('.tl-step');
  const stepObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('in');
    });
  }, { threshold: 0.5 });
  tlSteps.forEach(s => stepObserver.observe(s));

  function updateTimelineProgress() {
    if (!timeline) return;
    const rect = timeline.getBoundingClientRect();
    const vh = window.innerHeight;
    const total = rect.height;
    let progressed = vh * 0.75 - rect.top;
    progressed = Math.max(0, Math.min(progressed, total));
    const pct = total > 0 ? (progressed / total) * 100 : 0;
    timeline.style.setProperty('--tl-progress', pct + '%');
  }

  /* ---------------- Before / After Slider ---------------- */
  const baSlider = document.getElementById('baSlider');
  const baAfterImg = document.getElementById('baAfterImg');
  const baHandle = document.getElementById('baHandle');
  const baRange = document.getElementById('baRange');
  function setBaPosition(pct) {
    pct = Math.max(0, Math.min(100, pct));
    baAfterImg.style.clipPath = `inset(0 0 0 ${pct}%)`;
    baHandle.style.left = pct + '%';
  }
  if (baRange) {
    baRange.addEventListener('input', () => setBaPosition(baRange.value));
    setBaPosition(50);
  }

  /* ---------------- Testimonials carousel ---------------- */
  const tTrack = document.getElementById('tTrack');
  const tCards = document.querySelectorAll('.t-card');
  const tDotsWrap = document.getElementById('tDots');
  let tIndex = 0;
  function cardsPerView() {
    if (window.innerWidth <= 620) return 1;
    if (window.innerWidth <= 940) return 2;
    return 3;
  }
  function maxIndex() { return Math.max(0, tCards.length - cardsPerView()); }
  function buildDots() {
    tDotsWrap.innerHTML = '';
    const count = maxIndex() + 1;
    for (let i = 0; i < count; i++) {
      const dot = document.createElement('span');
      if (i === tIndex) dot.classList.add('active');
      dot.addEventListener('click', () => { tIndex = i; renderTestimonials(); });
      tDotsWrap.appendChild(dot);
    }
  }
  function renderTestimonials() {
    tIndex = Math.max(0, Math.min(tIndex, maxIndex()));
    const cardWidth = tCards[0].getBoundingClientRect().width + 24;
    tTrack.style.transform = `translateX(-${tIndex * cardWidth}px)`;
    buildDots();
    [...tDotsWrap.children].forEach((d, i) => d.classList.toggle('active', i === tIndex));
  }
  document.getElementById('tPrev').addEventListener('click', () => { tIndex = Math.max(0, tIndex - 1); renderTestimonials(); });
  document.getElementById('tNext').addEventListener('click', () => { tIndex = Math.min(maxIndex(), tIndex + 1); renderTestimonials(); });
  window.addEventListener('resize', renderTestimonials);
  setTimeout(renderTestimonials, 100);

  // Auto-slide
  let autoSlide = setInterval(() => {
    tIndex = tIndex >= maxIndex() ? 0 : tIndex + 1;
    renderTestimonials();
  }, 5000);
  [tTrack, tDotsWrap].forEach(el => {
    el.addEventListener('mouseenter', () => clearInterval(autoSlide));
    el.addEventListener('mouseleave', () => { autoSlide = setInterval(() => { tIndex = tIndex >= maxIndex() ? 0 : tIndex + 1; renderTestimonials(); }, 5000); });
  });

  /* ---------------- Appointment form ---------------- */
  const apptForm = document.getElementById('apptForm');
  const formSuccess = document.getElementById('formSuccess');
  // Prevent booking a past date
  const dateInput = document.getElementById('fDate');
  if (dateInput) dateInput.min = new Date().toISOString().split('T')[0];

  apptForm.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!apptForm.checkValidity()) { apptForm.reportValidity(); return; }
    formSuccess.classList.add('show');
    apptForm.reset();
    if (dateInput) dateInput.min = new Date().toISOString().split('T')[0];
    setTimeout(() => formSuccess.classList.remove('show'), 6000);
  });

  /* ---------------- Fab: scroll to top ---------------- */
  const fabTop = document.getElementById('fabTop');
  fabTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  /* ---------------- Button ripple ---------------- */
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', function (e) {
      const rect = this.getBoundingClientRect();
      const ripple = document.createElement('span');
      ripple.className = 'ripple';
      ripple.style.left = (e.clientX - rect.left) + 'px';
      ripple.style.top = (e.clientY - rect.top) + 'px';
      ripple.style.width = ripple.style.height = Math.max(rect.width, rect.height) + 'px';
      this.appendChild(ripple);
      setTimeout(() => ripple.remove(), 650);
    });
  });

  /* ---------------- Count-up (used only for non-fabricated, safe values) ---------------- */
  function countUp(el, target, duration = 1400) {
    const start = performance.now();
    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      el.textContent = Math.floor(progress * target);
      if (progress < 1) requestAnimationFrame(tick);
      else el.textContent = target;
    }
    requestAnimationFrame(tick);
  }
  document.querySelectorAll('[data-countup]').forEach(el => {
    const target = parseInt(el.dataset.countup, 10);
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) { countUp(el, target); obs.unobserve(el); }
      });
    }, { threshold: 0.6 });
    obs.observe(el);
  });

  // Initial calls
  onScroll();
});
